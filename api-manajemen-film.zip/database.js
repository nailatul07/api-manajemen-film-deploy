require('dotenv').config();
const sqlite3 = require('sqlite3').verbose();

const DB_SOURCE_1 = process.env.DB_SOURCE_1 || "movies.db";
const DB_SOURCE_2 = process.env.DB_SOURCE_2 || "directors.db";

const db_1 = new sqlite3.Database(DB_SOURCE_1, (err) => {
    if (err) {
        console.error(err.message);
        throw err;
    } else {
        console.log('Terhubung ke basis data SQLite.');
        db_1.run(`CREATE TABLE IF NOT EXISTS movies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            director TEXT NOT NULL,
            year INTEGER NOT NULL
        )`, (err) => {
            if (err) {
                return console.error("Gagal membuat tabel movies:", err.message);
            }

            db_1.get("SELECT COUNT(*) as count FROM movies", (err, row) => {
                if (err) {
                    return console.error(err.message);
                }

                if (row.count === 0) {
                    console.log("Menambahkan data awal ke tabel movies...");
                    const insert = 'INSERT INTO movies(title, director, year) VALUES(?, ?, ?)';
                    db_1.run(insert, ["Parasite", "Bong Joon-ho", 2019]);
                    db_1.run(insert, ["The Dark Knight", "Christopher Nolan", 2008]);
                    db_1.run(insert, ["Inception", "Christopher Nolan", 2010]);
                }
            });
        });
    }
});

const db_2 = new sqlite3.Database(DB_SOURCE_2, (err) => {
    if (err) {
        console.error(err.message);
        throw err;
    } else {
        db_2.run(`CREATE TABLE IF NOT EXISTS directors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            birthYear INTEGER NOT NULL
        )`, (err) => {
            if (err) {
                return console.error("Gagal membuat tabel directors:", err.message);
            }

            db_2.get("SELECT COUNT(*) as count FROM directors", (err, row) => {
                if (err) {
                    return console.error(err.message);
                }

                if (row.count === 0) {
                    console.log("Menambahkan data awal ke tabel directors...");
                    const insert = 'INSERT INTO directors(name, birthYear) VALUES(?, ?)';
                    db_2.run(insert, ["Bong Joon-ho", 1969]);
                    db_2.run(insert, ["Christopher Nolan", 1970]);
                    db_2.run(insert, ["Hayao Miyazaki", 1941]);
                }
            });
        });
    }
});

module.exports = { db_1, db_2 };